function [W,Z] = nonConvexCoefDiff(X, X_ko, y, option)
% KNOCKOFFS.STATS.NonConvexCOEFDIFF  Coefficient difference NonConvex regularization statistic W 
% with cross-validation
%   [W, Z] = KNOCKOFFS.STATS.NonConvexCOEFDIFF(X, X_ko, y)
%   [W, Z] = KNOCKOFFS.STATS.NonConvexCOEFDIFF(X, X_ko, y, nfolds)
%   [W, Z] = KNOCKOFFS.STATS.NonConvexCOEFDIFF(X, X_ko, y, nfolds, cv)
%
%   Computes the statistic
%
%     W_j = |Z_j| - |\tilde Z_j|,
%
%   where Z_j and \tilde Z_j are the coefficient values of the 
%   jth variable and its knockoff, respectively, resulting from
%   cross-validated SCAD and MCP regression.
%

% if ~exist('nfolds', 'var'), nfolds = []; end
% if ~exist('cv', 'var'), cv = 'lambda_1se'; end

p = size(X,2);

%%
% penalty = 'SCAD';           % SCAD OR MCP
% penparam = option.penparam;            % default SCAD 3.7 MCP 1
% XX = [X X_ko];
% penidx = ...                % leave intercept unpenalized
%     [false; true(size(XX,2)-1,1)];
% lambdastart = ...           % find the maximum tuning parameter to start
%     max(lsq_maxlambda(sum(XX(:,penidx).^2),-y'*XX(:,penidx),option.penalty,penparam));
% % display(lambdastart);
% lambda_max = lambdastart;

% Setting lambda %
lambda_max =norm([X X_ko]'*y,'inf'); % according to the https://github.com/yangziyi1990/SparseGDLibrary.git
lambda_min = lambda_max * 0.002;
k = option.nfolds;
% for i=1:nlambda
%     Lambda1(i)=lambda_max*(lambda_min/lambda_max)^(i/nlambda);
%     lambda=Lambda1(i);
%     fprintf('iteration times:%d\n',i);
% end
 i=1:option.nlambda;
Lambda = lambda_max*(lambda_min/lambda_max).^(i./option.nlambda);
% Lambda = 1:10;
opt_lambda = nonconvex_knockoffs.CV_NonConvex_LR([X X_ko],y,Lambda,k,option);
% lsq_sparsereg(X,y,lambda,'penalty',penalty,'penparam',penparam,'penidx',penidx);
betahat = ...               
    lsq_sparsereg([X X_ko],y,opt_lambda,'penalty',option.penalty,'penparam',option.penparam);

 Z = betahat;

% Z = cvglmnetCoef(cvglmnet([X X_ko],y,'gaussian',options,[],nfolds),cv);
% Z = Z(2:end); % drop intercept

W = abs(Z(1:p))-abs(Z((p+1):(2*p)));

end