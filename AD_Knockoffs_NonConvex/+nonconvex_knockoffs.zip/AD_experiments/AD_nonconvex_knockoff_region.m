%% This script reproduces experiments on lesion region selection of Alzheimer's Disease.  
clc;
clear;
root = pwd;
addpath(sprintf('%s/data/AALfeat', root));

data1 = 15;
data2 = 30;
%% Response Variable Y
% load 15 T data
y_AD = load(sprintf('ADAS_%d_AD.mat', data1)); 
y_AD = y_AD.ADAS;
y_MCI = load(sprintf('ADAS_%d_MCI.mat', data1));
y_MCI = y_MCI.ADAS;
y_NC = load(sprintf('ADAS_%d_NC.mat', data1));
y_NC = y_NC.ADAS;
y1 = [y_AD;y_MCI;y_NC];

% load 30 T data
y_AD = load(sprintf('ADAS_%d_AD.mat', data2)); 
y_AD = y_AD.ADAS;
y_MCI = load(sprintf('ADAS_%d_MCI.mat', data2));
y_MCI = y_MCI.ADAS;
y_NC = load(sprintf('ADAS_%d_NC.mat', data2));
y_NC = y_NC.ADAS;
y2 = [y_AD;y_MCI;y_NC];

y = [y1; y2];
index = find( y < 0);
y(index) = []; % rule out samples with invalid scores
y = nonconvex_knockoffs.normc(y);


%% Covariates X
% load 15 T data
X_AD = load(sprintf('AAL_%d_AD_feature_TIV.mat', data1));
X_AD = X_AD.feature_TIV;
X_MCI = load(sprintf('AAL_%d_MCI_feature_TIV.mat', data1));
X_MCI = X_MCI.feature_TIV;
X_NC = load(sprintf('AAL_%d_NC_feature_TIV.mat', data1));
X_NC = X_NC.feature_TIV;
X_1 = [X_AD; X_MCI;X_NC];

% load 30 T data
X_AD = load(sprintf('AAL_%d_AD_feature_TIV.mat', data2));
X_AD = X_AD.feature_TIV;
X_MCI = load(sprintf('AAL_%d_MCI_feature_TIV.mat', data2));
X_MCI = X_MCI.feature_TIV;
X_NC = load(sprintf('AAL_%d_NC_feature_TIV.mat', data2));
X_NC = X_NC.feature_TIV;
X_2 = [X_AD; X_MCI;X_NC];

X = [X_1; X_2];
X = double(X);
[n,~] = size(X);
X(index, :) = []; % rule out samples with invalid scores
id = [1:1:90]; % select Cerebrum
X = X(:,id);
X = nonconvex_knockoffs.normc(X);

%% Parameter Setting
connect = load('aalConect.mat');
option.nfolds = 5;
option.nlambda = 100;
option.penalty = 'SCAD'; % SCAD or MCP  or ENET(default LASSO with option.penparam=1) 
option.penparam = 3.7; % SCAD 3.7 or MCP 1
option.method = 'knockoff'; % knockoff or konckoff+(default)
option.create = 'asdp'; % sdp, asdp, equi. default sdp
% option.maxiter =  5000;
q = 0.2; 
repeats = 100;

mu = mean(X);
Sigma = cov(X);
myStatistc = @(X, X_ko, y) ...
    nonconvex_knockoffs.stats.nonConvexCoefDiff(X, X_ko, y,option);
Xmodel = {'gaussian', mu, Sigma};
modelx = {};
parfor i = 1:repeats
    modelx{i}=knockoffs.filter(X, y, q , Xmodel, 'Statistics', myStatistc, 'Method', option.create, 'Threshold', option.method);
end
mx = cell2mat(modelx);
tab_mx = tabulate(mx);
selected = tab_mx(tab_mx(:,2)>=(repeats/2));
selected_region = connect.aalLabel.Var2(selected);

% save results
% save(sprintf('%s/results/region_selectedbySCAD', pwd));