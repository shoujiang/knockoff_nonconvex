function [ Opt,Mse,opt_lambda] = CV_NonConvex_LR(X,y,Lambda,k,option)

%%%%%%%%%%%%%%     K cross validation    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
% k=5;            %%% K-fold%%%
% penalty = 'SCAD';           % set penalty function to SCAD
% penparam = 3.7;
[n,p] = size(X);
valida_n=floor(n/k);
sample_sequence=1:n;

for j=1:length(Lambda)
    lambda=Lambda(j);
    for i=1:k
        if i<=k-1
            validation_seq=sample_sequence(:,(i-1)*valida_n+1:i*valida_n);
        else
            validation_seq=sample_sequence(:,(i-1)*valida_n+1:n);
        end
        train_seq=setdiff(sample_sequence,validation_seq);
        X_train = X(train_seq,:);
        y_train = y(train_seq);
        X_validation= X(validation_seq, :);
        y_validation = y(validation_seq);
        
        beta=lsq_sparsereg(X_train,y_train,lambda,'penalty',option.penalty,'penparam',option.penparam);
        beta=beta(2:end);
        X_validation=X_validation(:,2:end);
        test_y = X_validation * beta;
        error=test_y-y_validation;  
        Mse(i,j)=sum(error.*error);
    end
end
[Number,Opt]=min(sum(Mse,1));
Mse=sum(Mse,1);
opt_lambda = Lambda(Opt);

end
