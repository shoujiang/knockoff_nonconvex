# Glmnet in Matlab
Lasso and elastic-net regularized generalized linear models. See https://web.stanford.edu/~hastie/glmnet_matlab/

We updated the package with compiled Mex-files for the newer verions of Matlab (2020a/b). Previous version is stored in the [matlab/R2013_older](https://github.com/junyangq/glmnet-matlab/tree/matlab/R2013_older) branch.

The new version was tested with Matlab 2020b on Mac OS 11 and with Matlab 2020a on CentOS Linux 7 (Core).
